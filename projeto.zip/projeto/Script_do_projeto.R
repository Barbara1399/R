
install.packages("ggplot2")  #para intalar o ggplot
library(ggplot2)  #para carregar a livraria
install.packages("readxl")
library(readxl)
install.packages("scatterplot3d")
library(scatterplot3d)
install.packages("factoextra")
library(factoextra)
install.packages("corrplot")
library(corrplot)
library(FactoMineR)
install.packages('rlang')
library(rlang)
install.packages("vctrs")
library(vctrs)

#para criar um data frame com os dados disponibilizados
df_covid <- read.csv("owid_g6.csv")
df_covid

#vizualizar a tabela 
View(df_covid)
#apenas as primeiras linhas
View(head(df_covid))
#sumario estatistico das colunas
summary(df_covid)
str(df_covid)



#----------------Africa-------------------------------
#data frame no qual temos os dados correspondentes apena ao continente Africa
df_A<-subset(df_covid, continent=="Africa")
View(df_A)

#summario estatistico relativo a Africa, no qual podemos ver quais colunas tem um numero relevante de NA,
summary(df_A)

#temos 54 paises de Africa
#decidimos assim eliminar os atributos com muitos NA
#positive_rate  e  tests_per_case tem 32 NA
df_A$positive_rate<-NULL
df_A$tests_per_case<-NULL
#extreme_poverty tem 13
df_A$extreme_poverty<-NULL
#female_smokers e  male_smokers tem 18
df_A$female_smokers<-NULL
df_A$male_smokers<-NULL
#hospital_beds_per_thousand tem 14
df_A$hospital_beds_per_thousand<-NULL


#Casostotais_A -------------------
CasosTotais_A <- df_A$total_cases
View(CasosTotais_A)
summary(CasosTotais_A)

#COM OUTLIERS - o diagrama de Ext. e quart. est� comprimido, devido aos outliers, para vizualizarmos melhor, temos que os eliminar apenas para a observa�ao
#---boxplot
boxplot(CasosTotais_A,boxwex = .7, xlab= "N�mero de casos", col = c( "brown"),horizontal = TRUE, main="Casos Totais em �frica (com outliers)") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#---histograma
hist(CasosTotais_A,xlab = "N�mero de casos totais",col = c( "brown"), ylab = "N�mero de pa�ses", breaks = 50, main = "Histograma dos Casos Totais em �frica (com outliers)") #histograma


#ggplot(CasosTotais_A, aes(x='N�mero de casos', color = brown))

ggplot(df_A, aes(x = CasosTotais_A,fill= 'brown')) +geom_boxplot()+labs(title = "Casos Totais em �frica com outliers",
                                                                        subtitle = "",
                                                                        x="",
                                                                        y="",
                                                                        fill="")
#+ title("Casos Totais em �frica com outliers")
!!!!!!!!!!!!!!!!!!!!!!!!!


#HISTOGRAMA NO GGPLOT
#ggplot(data = df_A, aes(x = CasosTotais_A)) +geom_histogram(bins=10, fill='blue')+ggtitle("Casos Totais em Africa")


#ggplot(data = df_A, aes(x = CasosTotais_A)) +geom_histogram() + ggtitle('Casos Totais em Africa')




#SEM OUTLIERS

boxplot.stats(CasosTotais_A)$out #Para vizualizar os valores dos outliers 

#---boxplot - Basta fazermos outline=FALSE
boxplot(CasosTotais_A,boxwex = .7,xlab= "N�mero de casos", col = c( "brown"), outline=FALSE,horizontal = TRUE, main="Casos Totais em �frica" )

#---histograma- precisamos de primeiro criar uma variavel que contem os dados da coluna CasosTotais_A mas sem os outliers mais relevantes
C<-CasosTotais_A[-c(46,16,38,37,36)] #os outliers maiores, estavam na linha 46,16,38,37, 36, com isto , eliminamo-las
View(C)
#Portanto, utilizamos a variavel C, em vez de cassototais, para uma melhor observa�ao
hist(C, breaks = 30,xlim = c(0,43000),ylim = c(0,20),xlab = "N�mero de casos totais",col = c( "brown"), ylab = "N�mero de pa�ses", main = "Histograma dos Casos Totais em �frica")


histCT_Aout<-ggplot(data=df_A, aes(x=C))
histCT_Aout
histCT_Aout+geom_histogram(bins = 30)
rlang::last_error()


#Populacao_A-----
Populacao_A<-df_A$population
View(Populacao_A)
summary(Populacao_A)

#COM OUTLIERS

#---boxplot
boxplot(Populacao_A,boxwex = .7, xlab= "N�mero de pessoas", col = c( "maroon"),horizontal = TRUE, main="Popula��o em �frica (com outliers)") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#---histograma
hist(Populacao_A,xlab = "N�mero de pessoas",col = c( "maroon"), ylab = "N�mero de pa�ses", breaks = 50,xlim = c(0,210000000),ylim = c(0,20), main = "Histograma da popula��o em �frica (com outliers)") #histograma

#GGPLOT
#Boxplot
ggplot(df_A, aes(x = Populacao_A,fill= 'maroon')) +geom_boxplot()+labs(title = "Popula��o em �frica com outliers",
                                                                        subtitle = "",
                                                                        x="",
                                                                        y="",
                                                                        fill="")

#SEM OUTLIERS

boxplot.stats(Populacao_A)$out #Para vizualizar os valores dos outliers 

#---boxplot - Basta fazermos outline=FALSE
boxplot(Populacao_A,boxwex = .7,xlab= "N�mero de pessoas", col = c( "maroon"), outline=FALSE,horizontal = TRUE, main="Popula��o em �frica" )

#---histograma- precisamos de primeiro criar uma variavel que contem os dados da coluna CasosTotais_A mas sem os outliers mais relevantes
P_A<-Populacao_A[-c(39,20,16,14)] #os outliers maiores, estavam na linha 39,20,16,14, com isto , eliminamo-las
View(P_A)
#Portanto, utilizamos a variavel P_A, em vez de popula��o, para uma melhor observa�ao
hist(P_A,xlab = "N�mero de pessoas",col = c( "maroon"), ylab = "N�mero de pa�ses", breaks = 30,xlim = c(0,40000000),ylim = c(0,10), main = "Histograma da popula��o em �frica") #histograma

#GGPLOT
#boxplot
ggplot(df_A, aes(x =P_A ,fill= 'maroon')) +geom_boxplot()+labs(title = "Popula��o em �frica sem outliers",
                                                                        subtitle = "",
                                                                        x="",
                                                                        y="",
                                                                        fill="")

#Testes_casos_A------
#como, numa primeira analise, eliminamos a coluna , precisamos dos seguintes comandos
Testes_casos_A1<-subset(df_covid, continent == "Africa")
Testes_casos_A<-na.omit(Testes_casos_A1$tests_per_case)
View(Testes_casos_A)
summary(Testes_casos_A)

#COM OUTLIERS

#---boxplot
boxplot(Testes_casos_A,boxwex = .7, xlab= "N�mero de testes", col = c( "red"),horizontal = TRUE, main="Testes por caso em �frica (com outliers)") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#---histograma
hist(Testes_casos_A,xlab = "N�mero de testes por caso",col = c( "red"), ylab = "N�mero de pa�ses", breaks = 50,xlim = c(0,350),ylim = c(0,25), main = "Histograma dos testes por caso em �frica (com outliers)") #histograma


#SEM OUTLIERS

boxplot.stats(Testes_casos_A)$out #Para vizualizar os valores dos outliers 

#---boxplot - Basta fazermos outline=FALSE
boxplot(Testes_casos_A,boxwex = .7,xlab= "N�mero de testes", col = c( "Red"), outline=FALSE,horizontal = TRUE, main="Testes por caso em �frica" )

#---histograma- precisamos de primeiro criar uma variavel que contem os dados da coluna CasosTotais_A mas sem os outliers mais relevantes
TC_A<-Testes_casos_A[-c(2,19,22,27,28)] #os outliers maiores, estavam na linha 46,16,38,37, 36, com isto , eliminamo-las
View(TC_A)
#Portanto, utilizamos a variavel TC_A, em vez de Testes casos, para uma melhor observa�ao
hist(TC_A,xlab = "N�mero de testes por caso",col = c( "red"), ylab = "N�mero de pa�ses", breaks = 30,xlim = c(0,60),ylim = c(0,5.5), main = "Histograma dos testes por caso em �frica") #histograma



#GGPLOT 
#BOXPLOT 

ggplot(df_A, aes(x = Testes_casos_A,fill= 'red')) +geom_boxplot()+labs(title = "Testes por caso  em �frica com outliers",
                                                                        subtitle = "",
                                                                        x="",
                                                                        y="",
                                                                        fill="")

#----CasosTotais-Popula�ao_A-----------

#COM OUTLIERS

#---Plot

plot(CasosTotais_A, Populacao_A) #para representar o diagrama de dispersao

#---Correla��o de pearson

cor(CasosTotais_A, Populacao_A ) #a correla��o tem um valor de aprox. 0.271 que corresponde a uma correla�ao baixa

#---regress�o linear

mreg_CP_A<-lm(CasosTotais_A~Populacao_A) # CasosTotais_A~Populacao_A significa que queremos os casos totais em fun��o da popula��o
mreg_CP_A

abline(mreg_CP_A, col=c("maroon"), lwd=2) #para visualizar a reta de regressao

summary(mreg_CP_A) #para obter a qualidade do ajustamento (o R^2)

#---GGplot
install.packages("ggplot2")  #para intalar o ggplot
library(ggplot2)  #para carregar a livraria

gg_CP_A<-ggplot(data=df_A ,aes(x=CasosTotais_A, y=Populacao_A))+geom_point(color="maroon") #grafico de dispers�o ggplt

gg_CP_A+xlab("Casos Totais")+ylab("Popula�ao")+ggtitle("Grafico de dispersao") #com legendas

gg_CP_A

#a nossa tentativa de reta de regress�o linear
abline(gg_CP_A) #este n�o d�
gg_CP_A1<-ggplot(data=df_A ,aes(x=CasosTotais_A, y=Populacao_A))+geom_point(color="maroon")+geom_smooth(method=lm, se=FALSE) #grafico de dispers�o ggplt
gg_CP_A1 #este � estranho



#SEMOUTLIERS

plot(CasosTotais_A, Populacao_A, outline=FALSE) #tentativa falhada
plot.stats(CasosTotais_A, Populacao_A)$out #tmb nao

#temos a variavel C e P_A sem outliers

plot(C,P_A)  # <3  
#este ja da, temos que legendar 


#----------------------------




#entre total_cases e total_deaths
MortesTotais <- df_A$total_deaths

#como mortes totais tem 2 valores NA
df_A1<-na.omit(df_A)   #temos que eliminar as linhas com NA
df_A1
MortesTotais <- df_A1$total_deaths
CasosTotais <- df_A1$total_cases

plot(MortesTotais, CasosTotais)
plot(CasosTotais, MortesTotais)
boxplot(MortesTotais, CasosTotais)
boxplot(CasosTotais, MortesTotais)
cor(MortesTotais, CasosTotais) # correlacao de pearson de 0.9299251 o que significa que, existe uma correlacao muito forte

boxplot(CasosTotais, MortesTotais)$out


# pretendemos analisar a relacao entre as colunas total_cases e total_deaths
#entre reproduction_rate e total_cases
#entre population_density e total_cases
#gdp_per_capita e total_cases
#aged_70_older e total_deaths e total_cases

#analise estatistica por continente

#----------------Oceania------------------------------
#data frame no qual temos os dados correspondentes apenas ao continente Oceania
df_O<-subset(df_covid, continent=="Oceania")
View(df_O)

#summario estatistico relativo a Oceania
summary(df_O) 

#temos 4 pa�ses naOceania
#tem 2ou mais NA
df_O$reproduction_rate<-NULL
df_O$tests_per_case<-NULL
df_O$extreme_poverty<-NULL
df_O$handwashing_facilities<-NULL
#CasosTotais_O-----------
CasosTotais_O <- df_O$total_cases
View(CasosTotais_O)

summary(CasosTotais_O)

#Para vizualizar os valores dos outliers :
boxplot.stats(CasosTotais_O)$out  #portanto , nao existem outliers

#podemos entao fazer o boxplot  e hist sem os remover
#boxplot
boxplot(CasosTotais_O,boxwex = .7, xlab= "N�mero de casos", col = c( "yellow"),horizontal = TRUE, main="Casos Totais na Oceania")
#Histograma
hist(CasosTotais_O, breaks = 20,xlim = c(0,18000),ylim = c(0,2),col = c( "yellow"), main = "Histograma dos Casos Totais na Oceania")



#Populacao_O-----
Populacao_O<-df_O$population
View(Populacao_O)
summary(Populacao_O)

#---boxplot
boxplot(Populacao_O,boxwex = .7, xlab= "Popula��o", col = c( "light yellow"),horizontal = TRUE, main="Popula��o na Oceania") #boxplot 
#---histograma
hist(Populacao_O,xlab = "Popula��o",col = c( "light yellow"), ylab = "N�mero de pa�ses", breaks = 50,xlim = c(0,10000000),ylim = c(0,1), main = "Histograma da popula��o na Oceania")


#Testes_casos_O------
#como, numa primeira analise, eliminamos a coluna , precisamos dos seguintes comandos
Testes_casos_O<-na.omit(subset(df_covid$tests_per_case, continent=="Oceania"))
View(Testes_casos_O)
summary(Testes_casos_O)

#---boxplot
boxplot(Testes_casos_O,boxwex = .7, xlab= "N�mero de testes", col = c( "orange"),horizontal = TRUE, main="Testes por caso na Oceania")
#---histograma
hist(Testes_casos_O,xlab = "N�mero de testes por caso",col = c( "orange"), ylab = "N�mero de pa�ses", breaks = 50,xlim = c(0,350),ylim = c(0,25), main = "Histograma dos testes por caso na Oceania")
#----------------South America------------------------
#data frame no qual temos os dados correspondentes apenas ao continente da Am�rica do Sul
df_SA<-subset(df_covid, continent=="South America")
View(df_SA)

#summario estatistico relativo a America do sum, no qual podemos ver quais colunas tem um numero relevante de NA,
summary(df_SA)

#temos dados sobre 12 paises
#Iremos remover as tabelas que tem metade dos paises com NA nas colunas para a analise dos dados da America do sul
df_SA$positive_rate<-NULL
df_SA$tests_per_case<-NULL
df_SA$handwashing_facilities<-NULL
#CasosTotais_SA --------------------
CasosTotais_SA <- df_SA$total_cases
View(CasosTotais_SA)

boxplot(CasosTotais_SA, main="Casos Totais na Am�rica do Sul") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido

hist(CasosTotais_SA, breaks = 100, main = "Histograma dos Casos Totais na Am�rica do Sul") #histograma

summary(CasosTotais_SA)

#Para vizualizar os valores dos outliers :
boxplot.stats(CasosTotais_SA)$out

#COM OUTLIERS
#---boxplot
boxplot(CasosTotais_SA,boxwex = .7, xlab= "N�mero de casos", col = c( "blue"),horizontal = TRUE, main="Casos Totais em Am�rica do Sul (com outliers)") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido
#---histograma
hist(CasosTotais_SA,xlab = "N�mero de casos totais",col = c( "blue"), ylab = "N�mero de pa�ses", breaks = 50, main = "Histograma dos Casos Totais em Am�rica do Sul (com outliers)") #histograma

#SEM OUTLIERS

#-----boxplot 
boxplot(CasosTotais_SA,boxwex = .7,xlab= "N�mero de casos", col = c( "blue"), outline=FALSE,horizontal = TRUE, main="Casos Totais na Am�rica do Sul" )

#---histograma
C_SA<-CasosTotais_SA[-3] #o outlier estava na linha 3, com isto , eliminamo-la
summary(C_SA)
hist(C_SA, breaks = 30,xlim = c(0,407500),ylim = c(0,4),xlab = "N�mero de casos totais",col = c( "blue"), ylab = "N�mero de pa�ses", main = "Histograma dos Casos Totais em Am�rica do Sul")

#Populacao_SA----
Populacao_SA<-df_SA$population
View(Populacao_SA)
summary(Populacao_SA)

#COM OUTLIERS
#---boxplot
boxplot(Populacao_SA,boxwex = .7, xlab= "N�mero de pessoas", col = c( "light blue"),horizontal = TRUE, main="Popula��o em America do sul (com outliers)") #boxplot incluindo os ouliers, � possivel vizualizar que este fica comprimido

#---histograma
hist(Populacao_SA,xlab = "N�mero de pessoas",col = c( "light blue"), ylab = "N�mero de pa�ses", breaks = 30,xlim = c(0,210000000),ylim = c(0,4), main = "Histograma da popula��o em America do sul (com outliers)")

#SEM OUTLIERS

boxplot.stats(Populacao_SA)$out #Para vizualizar os valores dos outliers 
#---boxplot - Basta fazermos outline=FALSE
boxplot(Populacao_SA,boxwex = .7,xlab= "N�mero de pessoas", col = c( "light blue"), outline=FALSE,horizontal = TRUE, main="Popula��o em America do sul" )
#---histograma- precisamos de primeiro criar uma variavel que contem os dados da coluna CasosTotais_A mas sem os outliers mais relevantes
P_SA<-Populacao_SA[-c(3)] #os outliers maiores, estavam na linha  3, com isto , eliminamo-la
View(P_SA)
#Portanto, utilizamos a variavel P_SA, em vez de popula��o, para uma melhor observa�ao
hist(P_SA,xlab = "N�mero de pessoas",col = c( "light blue"), ylab = "N�mero de pa�ses", breaks = 30,xlim = c(0,35000000),ylim = c(0,2), main = "Histograma da popula��o em Am�rica do Sul") #histograma

#Testes_casos_SA------
Testes_casos_SA<-na.omit(subset(df_covid$tests_per_case, continent=="South America"))
View(Testes_casos_SA)
summary(Testes_casos_SA)

#COM OUTLIERS

#---boxplot
boxplot(Testes_casos_SA,boxwex = .7, xlab= "N�mero de testes", col = c( "cyan"),horizontal = TRUE, main="Testes por caso em Am�rica do Sul (com outliers)") #boxplot incluindo os outliers
#---histograma
hist(Testes_casos_SA,xlab = "N�mero de testes por caso",col = c( "cyan"), ylab = "N�mero de pa�ses", breaks = 50,xlim = c(0,350),ylim = c(0,25), main = "Histograma dos testes por caso em Am�rica do Sul (com outliers)") #histograma

#SEM OUTLIERS

boxplot.stats(Testes_casos_A)$out #Para vizualizar os valores dos outliers

#---boxplot - Basta fazermos outline=FALSE
boxplot(Testes_casos_SA,boxwex = .7,xlab= "N�mero de testes", col = c( "cyan"), outline=FALSE,horizontal = TRUE, main="Testes por caso em America do Sul" )
#---histograma- precisamos de primeiro criar uma variavel que contem os dados da coluna CasosTotais_A mas sem os outliers mais relevantes
TC_SA<-Testes_casos_SA[-c(???)] #os outliers maiores, estavam na linha ???? com isto , eliminamo-las
View(TC_SA),
#Portanto, utilizamos a variavel TC_SA, em vez de Testes casos, para uma melhor observa�ao
hist(TC_SA,xlab = "N�mero de testes por caso",col = c( "cyan"), ylab = "N�mero de pa�ses", breaks = 30,xlim = c(0,60),ylim = c(0,5.5), main = "Histograma dos testes por caso em America") #histograma



#-----------------

#Agora comparando entre paises


#-------Entre Africa e na Am�rica do Sul ----------

#Casos Totais------------

#COM OUTLIERS

#---boxplot
boxplot(CasosTotais, CasosTotais_SA, horizontal = TRUE,col = c( "brown","blue"),names = c("�frica","Am�rica do Sul"), main="Casos Totais em Africa e na Am�rica do Sul (com outliers) ")

#---Histograma
CT_ASA <- c(CasosTotais, CasosTotais_SA) #criamos uma variavel que contem os valores dos dois
View(CT_ASA),

hist(CT_ASA,xlab = "Casos totais", breaks = 10,xlim = c(0,2700000),ylim = c(0,50),col = c( "brown","blue"), main="Casos Totais em Africa e na Am�rica do Sul (com outliers)"),

#SEM OUTLIERS
#---boxplot
boxplot(CasosTotais, CasosTotais_SA, outline = FALSE, horizontal = TRUE,col = c( "brown","blue"), main="Casos Totais em Africa e na Am�rica do Sul ")

#---Histograma
#Para vizualizar os outliers
boxplot.stats(CT_ASA)$out

CT_ASA1<-CT_ASA[-c(46,55 ,57, 58 ,59 ,63)] 

View(CT_ASA1)
hist(CT_ASA1,xlab = "N�mero de Popula��o", ylab = "N�mero de Paises",col = c( "brown","blue"), breaks = 30,xlim = c(0,500000),ylim = c(0,50), main="Casos Totais em Africa e na Am�rica do Sul")
#Popula��o----
#COM OUTLIERS

#---boxplot
boxplot(Populacao_A, Populacao_SA, horizontal = TRUE,col = c( "brown","blue"),names = c("�frica","Am�rica do Sul"), main="Popula��o em Africa e na Am�rica do Sul (com outliers) ")

#---Histograma
P_ASA <- c(Populacao_A, Populacao_SA) #criamos uma variavel que contem os valores dos dois
View(P_ASA)

hist(P_ASA,xlab = "Popula��o", breaks = 50,xlim = c(0,65000000),ylim = c(0,50),col = c( "brown","blue"), main="Popula��o em Africa e na Am�rica do Sul (com outliers)")

#SEM OUTLIERS
#---boxplot
boxplot(Populacao_A, Populacao_SA, outline = FALSE, horizontal = TRUE,col = c( "brown","blue"), main="Popula��o em Africa e na Am�rica do Sul ")

#---Histograma
#Para vizualizar os outliers
boxplot.stats(P_ASA)$out

P_ASA1<-P_ASA[-c(46,55 ,57, 58 ,59 ,63)]

View(P_ASA1)
hist(P_ASA1,xlab = "N�mero de Popula��o", ylab = "N�mero de Paises",col = c( "brown","blue"), breaks = 50,xlim = c(0,65000000),ylim = c(0,50), main="Casos Totais em Africa e na Am�rica do Sul")

#-------Entre Africa e Oceania----------

#Casos Totais------------

#COM OUTLIERS

#---boxplot
boxplot(CasosTotais, CasosTotais_O,horizontal = TRUE,col = c( "brown","yellow"), names = c("�frica","Oceania"), main="Casos Totais em Africa e na Oceania (com outliers) ")

#---Histograma
CT_AO <- c(CasosTotais, CasosTotais_O) #criamos uma variavel que contem os valores dos dois
View(CT_AO)

hist(CT_AO,xlab = "Casos totais", breaks = 50,xlim = c(0,100000),ylim = c(0,30),col = c( "brown","yellow"), main="Casos Totais em Africa e na Oceania (com outliers)")
#SEM OUTLIERS

#---boxplot
boxplot(CasosTotais, CasosTotais_O, outline = FALSE,horizontal = TRUE,col = c( "brown","yellow"), names = c("�frica","Oceania"), main="Casos Totais em Africa e na Oceania ")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(CT_AO)$out

CT_AO1<-CT_AO[-c(32,12,28,16,1)]# vamos eliminar todos, 

View(CT_AO1)
hist(CT_AO1,xlab = "N�mero de Casos totais", ylab = "N�mero de Paises",col = c( "brown","yellow"), breaks = 30,xlim = c(0,10000),ylim = c(0,5), main="Casos Totais em Africa e na Oceania")
#Popula��o----
#COM OUTLIERS

#---boxplot
boxplot(Populacao_A, Populacao_O,horizontal = TRUE,col = c( "brown","yellow"), names = c("�frica","Oceania"), main="Popula��o em Africa e na Oceania (com outliers) ")

#---Histograma
P_AO <- c(Populacao_A, Populacao_O) #criamos uma variavel que contem os valores dos dois
View(P_AO)

hist(P_AO,xlab = "Popula��o", breaks = 100,xlim = c(0,60000000),ylim = c(0,10),col = c( "brown","yellow"), main="Popula��o em Africa e na Oceania (com outliers)")
#SEM OUTLIERS

#---boxplot
boxplot(Populacao_A, Populacao_O, outline = FALSE,horizontal = TRUE,col = c( "brown","yellow"), names = c("�frica","Oceania"), main="Popula��o em Africa e na Oceania ")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(P_AO)$out

P_AO1<-P_AO[-c(32,12,28,16,1)]# vamos eliminar todos, 

View(P_AO1)
hist(P_AO1,xlab = "Popula��o", ylab = "N�mero de Paises",col = c( "brown","yellow"), breaks = 30,xlim = c(0,90000000),ylim = c(0,20), main="Popula��o em Africa e na Oceania")

#-------Entre Am�rica do Sul e Oceania------------

#Casos Totais------------

#COM OUTLIERS

#---boxplot
boxplot(CasosTotais_SA, CasosTotais_O,horizontal = TRUE,col = c( "blue","yellow"), names = c("America do Sul","Oceania"), main="Casos Totais na America do Sul e na Oceania (com outliers) ")
#---Histograma
CT_SAO <- c(CasosTotais_SA, CasosTotais_O) #criamos uma variavel que contem os valores dos dois
View(CT_SAO)

hist(CT_SAO,xlab = "Casos totais", breaks = 10,xlim = c(0,2700000),ylim = c(0,15),col = c( "blue","yellow"), main="Casos Totais em Oceania e na Am�rica do Sul (com outliers)")
#SEM OUTLIERS

#---boxplot
boxplot(CasosTotais_SA, CasosTotais_O, outline = FALSE,horizontal = TRUE,col = c( "blue","yellow"), names = c("America do Sul","Oceania"), main="Casos Totais na America do Sul e na Oceania ")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(CT_SAO)$out

CT_SAO1<-CT_SAO[-c(3)]#vamos eliminar todos

View(CT_SAO1)
hist(CT_SAO1,xlab = "N�mero de Casos totais", ylab = "N�mero de Paises",col = c( "blue","yellow"), breaks = 30,xlim = c(0,430000),ylim = c(0,8), main="Casos Totais em Am�rica do Sul e Oceania")
#Popula��o----
#COM OUTLIERS

#---boxplot
boxplot(Populacao_SA, Populacao_O,horizontal = TRUE,col = c( "blue","yellow"), names = c("America do Sul","Oceania"), main="Popula��o na America do Sul e na Oceania (com outliers) ")
#---Histograma
P_SAO <- c(Populacao_SA, Populacao_O) #criamos uma variavel que contem os valores dos dois
View(P_SAO)

hist(P_SAO,xlab = "Popula��o", breaks = 10,xlim = c(0,270000000),ylim = c(0,10),col = c( "blue","yellow"), main="Popula��o em Oceania e na Am�rica do Sul (com outliers)"),
#SEM OUTLIERS

#---boxplot
boxplot(Populacao_SA, Populacao_O, outline = FALSE,horizontal = TRUE,col = c( "blue","yellow"), names = c("America do Sul","Oceania"), main="Popula��o na America do Sul e na Oceania ")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(P_SAO)$out

P_SAO1<-P_SAO[-c(3)]#vamos eliminar todos

View(P_SAO1)
hist(P_SAO1,xlab = " Popula��o", ylab = "N�mero de Paises",col = c( "blue","yellow"), breaks = 30,xlim = c(0,56000000),ylim = c(0,3), main="Popula��o em Am�rica do Sul e Oceania")
#-------Entre Am�rica do Sul, Africa e Oceania----

#.....As 3 variaveis para a tentativa-----------

#Regress�o multipla para as 3 variaveis dos 3 continentes

#Criando variaveis com apenas as colunas que pretendemos estudar

CasosTotais<-df_covid$total_cases
Populacao<-df_covid$population
Testes_Casos<-df_covid$tests_per_case

#COM OUTLIERS ----(nao sei se vai ser preciso tirar, ou se temos que estuda-las assim)

#s� com 2 variavies
plot(CasosTotais, Populacao) #para representar o diagrama de dispersao

gg_CP<-ggplot(data=df_covid ,aes(x=CasosTotais, y=Populacao))+geom_point(aes(color=continent)) #grafico de dispers�o ggplt
gg_CP
ggplot_CP<-gg_CP+xlab("Casos Totais")+ylab("Popula�ao")+ggtitle("Grafico de dispersao") #com legendas
ggplot_CP

cor(CasosTotais, Populacao)#---Correla��o de pearson de 0.60522

mreg_CP_ASAO<-lm(CasosTotais~Populacao) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_CP_ASAO+

abline(mreg_CP_ASAO, col=c("maroon"), lwd=2)#nao aparece no gg plot, so no plot

geom_abline(mreg_CP_ASAO, col=c("maroon"), lwd=2)#aiiiiii

summary(mreg_CP_ASAO)#valores de r^2 para apenas 2 variaveis


#para as 3 variaveis

plot(CasosTotais, Populacao + Testes_Casos)

cor(CasosTotais, Populacao + Testes_Casos)

mreg_CPT_ASAO<-lm(CasosTotais~Populacao+Testes_Casos) #criar a reta de regress�o linear para as variaveis
mreg_CPT_ASAO

abline(mreg_CPT_ASAO, col=c("maroon"), lwd=2)#nao aparece no gg plot, so no plot
geom_abline()
summary(mreg_CPT_ASAO) #R^2 para as 3 variaveis

#temos de comparar o valor de R^2 com as 2 e com 3 variaveis, o que muda quando se add 1?


#SEM OUTLIERS
CT<-boxplot.stats(CasosTotais)$out
CTout<-CasosTotais[-c(CT)]
View(CT_ASAO1)

CasosTotais<-df_covid$total_cases
Populacao<-df_covid$population
Testes_Casos<-df_covid$tests_per_case

#Casos totais e popula��o------------

#Cluster com o ggplot e cenas---------------

#COM OUTLIERS
gg_CP<-ggplot(data=df_covid ,aes(x=CasosTotais, y=Populacao+Testes_Casos))+geom_point(aes(color=continent)) #grafico de dispers�o ggplt
gg_CP
ggplot_CP<-gg_CP+xlab("Casos Totais")+ylab("Popula�ao e testes por caso")+ggtitle("Grafico de dispersao") #com legendas
ggplot_CP

#SEM OUTLIERS




#Casos Totais----

#COM OUTLIERS

#---boxplot
boxplot(CasosTotais_A, CasosTotais_O,CasosTotais_SA,horizontal = TRUE,col = c( "brown","yellow","blue"), names = c("�frica","Oceania","Am�rica do Sul"), main="Casos Totais em Africa, na Oceania e America do Sul (com outliers) ")
#---Histograma
CT_ASAO <- c(CasosTotais, CasosTotais_SA,CasosTotais_O) #criamos uma variavel que contem os valores dos dois
View(CT_ASAO)
hist(CT_ASAO,xlab = "Casos totais", breaks = 10,xlim = c(0,2700000),ylim = c(0,50),col = c( "brown","blue","yellow"), main="Casos Totais em Africa, na Am�rica do Sul e Oceania (com outliers)")

#SEM OUTLIERS
#---boxplot
boxplot(CasosTotais_A, CasosTotais_O,CasosTotais_SA, outline = FALSE,horizontal = TRUE,col = c( "brown","yellow","blue"), names = c("Africa","Oceania","Am�rica do Sul"), main="Casos Totais na Africa, na Oceania e America do Sul")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(CT_ASAO)$out

CT_ASAO1<-CT_ASAO[-c(42,32 ,48, 43 ,44 ,40,12,45,41)]#nao vamos eliminar todos, apenas os que achamos mais relevantes
CT_ASAO1
hist(CT_ASAO1,xlab = "N�mero de Casos totais", ylab = "N�mero de Paises",col = c( "brown","yellow","blue"), breaks = 30,xlim = c(0,50000),ylim = c(0,20), main="Casos Totais em Africa, na Am�rica do Sul e Oceania")

#Popula��o----
#COM OUTLIERS

#---boxplot
boxplot(Populacao_A, Populacao_O,Populacao_SA,horizontal = TRUE,col = c( "brown","yellow","blue"), names = c("�frica","Oceania","Am�rica do Sul"), main="Popula��o em Africa, na Oceania e America do Sul (com outliers) ")
#---Histograma
P_ASAO <- c(Populacao_A, Populacao_SA,Populacao_O) #criamos uma variavel que contem os valores dos dois
View(P_ASAO)
hist(P_ASAO,xlab = "Popula��o", breaks = 10,xlim = c(0,230000000),ylim = c(0,50),col = c( "brown","blue","yellow"), main="Popula��o em Africa, na Am�rica do Sul e Oceania (com outliers)")

#SEM OUTLIERS
#---boxplot
boxplot(Populacao_A, Populacao_O,Populacao_SA, outline = FALSE,horizontal = TRUE,col = c( "brown","yellow","blue"), names = c("Africa","Oceania","Am�rica do Sul"), main="Popula��o na Africa, na Oceania e America do Sul")
#---Histograma
#Para vizualizar os outliers
boxplot.stats(P_ASAO)$out

P_ASAO1<-P_ASA[-c(42,32 ,48, 43 ,44 ,40,12,45,41)]#nao vamos eliminar todos, apenas os que achamos mais relevantes
P_ASAO1
hist(P_ASAO1,xlab = "Popula��o", ylab = "N�mero de Paises",col = c( "brown","yellow","blue"), breaks = 30,xlim = c(0,230000000),ylim = c(0,25), main="Popula��o em Africa, na Am�rica do Sul e Oceania")





#----------------------------------------------------------------------------------------------

#Regressao linear-------------------

View(df_covid)
summary(df_covid)

#As 3 variaveis a usar em relat�rio
#cardiovasc_death_rate  , life_expectancy  ,  diabetes_prevalence

Mortes_Cardio<- df_covid$cardiovasc_death_rate
Esp_Vida <- df_covid$life_expectancy
Diabetes<- df_covid$diabetes_prevalence


#-------------
boxplot.stats(Mortes_Cardio)$out #outliers de Mortes_Cardio
View(Mortes_Cardio) #para observarmos as linhas todas, e saber qual o nr da correspondente aos outliers
MC_out<-Mortes_Cardio[-c(50, 23)] #removemos os outliers
MC_out  #� a variavel a usar para um grafico sem outliers
View(MC_out) #verificarmos se ficou sem outliers

boxplot.stats(Esp_Vida)$out #outliers de Esp_Vida, nao tem porque diz "numeric(0)"
View(Esp_Vida) #confirmando...
Esp_Vida#portanto iremos usar Esp_Vida para os graficos sem outliers

boxplot.stats(Diabetes)$out #outliers de Diabetes
View(Diabetes)
D_out<-Diabetes[-c(23,28,43, 50, 61)]
D_out #vai ser a variavel a usar
View(D_out)



#comparar apenas 2------------
#Mortes_Cardio e Esp_Vida
#COM OUTLIERS
plot(Esp_Vida,Mortes_Cardio, col = 'maroon',pch = 19,
     xlab = 'Esperan�a de Vida', ylab = "Mortes Cardio-vasculares", title("Gr�fico de dispers�o"))

mreg_ME_ASAO<-lm(Esp_Vida~Mortes_Cardio) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_ME_ASAO
abline(mreg_ME_ASAO, col=c("gray"), lwd=3)#nao aparece no gg plot, so no plot

cor(Esp_Vida, Mortes_Cardio) #correla��o de -0.4245696, ou seja moderada negativa

gg_ME<-ggplot(data=df_covid ,aes(x=Esp_Vida, y=Mortes_Cardio),cex.axis=4)+geom_point(aes(color=continent))+ geom_smooth(method = lm, se=FALSE) #grafico de dispers�o ggplt

ggplot_ME<-gg_ME+xlab("Esperan�a de vida")+ylab("Mortes Cardiovascular")+ggtitle("Grafico de dispersao")#com legendas
ggplot_ME
#neste grafico � possivel verificar alguns outliers,
#sendo os mais relevantes (os dois da direita, pertencendo � africa e oceania)


summary(mreg_ME_ASAO) #R^2 para as duas variaveis
#falta interpretar



#SEM OUTLIERS--??---------------

boxplot.stats(Mortes_Cardio)$out #outliers de Mortes_Cardio
View(Mortes_Cardio) #para observarmos as linhas todas, e saber qual o nr da correspondente aos outliers
MC_out<-Mortes_Cardio[-c(28,43,50, 23, 61)] #removemos os outliers
MC_out  #� a variavel a usar para um grafico sem outliers
View(MC_out) #verificarmos se ficou sem outliers

boxplot.stats(Esp_Vida)$out #outliers de Esp_Vida, nao tem porque diz "numeric(0)"
View(Esp_Vida) #confirmando...
EV_out<-Esp_Vida[-c(23,28,43, 50, 61)]
EV_out #vai ser a variavel a usar
View(EV_out)

boxplot.stats(Diabetes)$out #outliers de Diabetes
View(Diabetes)
D_out<-Diabetes[-c(23,28,43, 50, 61)]
D_out #vai ser a variavel a usar
View(D_out)


plot(MC_out, EV_out)
mreg_ME_out_ASAO<-lm(MC_out ~ EV_out) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_ME_out_ASAO
abline(mreg_ME_out_ASAO, col=c("maroon"), lwd=2)#nao aparece no gg plot, so no plot

cor(Mortes_Cardio, Esp_Vida) #correla��o de -0.4245696, ou seja moderada negativa

gg_ME_out<-ggplot(data=df_covid ,aes(x=MC_out, y=EV_out))+geom_point(aes(color=continent)) #grafico de dispers�o ggplt
ggplot_ME_out<-gg_ME_out+xlab("Mortes Cardiovascular")+ylab("Esperan�a de vida")+ggtitle("Grafico de dispersao") #com legendas
ggplot_ME_out

summary(mreg_ME_out_ASAO)




#comparando 3 variaveis----------------------
plot(Mortes_Cardio, Esp_Vida+Diabetes)
mreg_MED_ASAO<-lm(Mortes_Cardio ~ Esp_Vida+Diabetes) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_MED_ASAO
abline(mreg_MED_ASAO, col=c("maroon"), lwd=2)#vizualizando-a

cor(Mortes_Cardio, Esp_Vida+Diabetes) #correla��o de -0.2007994, ou seja baixa negativa

gg_MED<-ggplot(data=df_covid ,aes(x=Mortes_Cardio, y=Esp_Vida+Diabetes),col('blue'))+geom_point(aes(color=continent)+ geom_smooth(method = lm, se=FALSE)) #grafico de dispers�o ggplt
ggplot_MED<-gg_MED+xlab("Mortes Cardiovascular")+ylab("Esperan�a de vida e diabetes")+ggtitle("Grafico de dispersao")#com legendas
ggplot_MED 

summary(mreg_MED_ASAO) #R^2 para as 3 variaveis

#Esp_Vida,Mortes_Cardio +Diabetes-------
plot(Esp_Vida,Mortes_Cardio +Diabetes)
mreg_MED_ASAO1<-lm(Esp_Vida ~ Mortes_Cardio +Diabetes) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_MED_ASAO1
abline(mreg_MED_ASAO1, col=c("blue"), lwd=2)#vizualizando-a

cor(Esp_Vida,Mortes_Cardio +Diabetes) #correla��o de -0.4041465, ou seja moderada negativa

gg_MED1<-ggplot(data=df_covid ,aes(x=Mortes_Cardio, y=Esp_Vida+Diabetes))+geom_point(aes(color=continent)+ geom_smooth(method = lm, se=FALSE)) #grafico de dispers�o ggplt
ggplot_MED1<-gg_MED1+xlab("Esperan�a de vida")+ylab("Mortes Cardiovascular e diabetes")+ggtitle("Grafico de dispersao") #com legendas
ggplot_MED1 

summary(mreg_MED_ASAO1)


#Diabetes,Mortes_Cardio +Esp_Vida--------------
plot(Diabetes,Mortes_Cardio +Esp_Vida)
mreg_MED_ASAO2<-lm(Diabetes ~ Mortes_Cardio +Esp_Vida) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_MED_ASAO2
abline(mreg_MED_ASAO2, col=c("orange"), lwd=2)#vizualizando-a

cor(Esp_Vida,Mortes_Cardio +Diabetes) #correla��o de -0.4041465, ou seja moderada negativa

gg_MED2<-ggplot(data=df_covid ,aes(x=Diabetes, y=Mortes_Cardio+Esp_Vida))+geom_point(aes(color=continent)+ geom_smooth(method = lm, se=FALSE)) #grafico de dispers�o ggplt
ggplot_MED2<-gg_MED2+xlab("Diabetes")+ylab("Mortes Cardiovascular e Esperan�a de vida")+ggtitle("Grafico de dispersao") #com legendas
ggplot_MED2

summary(mreg_MED_ASAO2)



#REGRESS�O LINEAR NA AM�RICA DO SUL-----------------------------------------------------------------------------------------

Cardio<- df_SA$cardiovasc_death_rate
Vida <- df_SA$life_expectancy
Diab<- df_SA$diabetes_prevalence

#2 variaveis 
plot(Vida,Cardio,  col = 'orange',pch = 19,
     xlab = 'Esperan�a de Vida', ylab = "Mortes Cardio-vasculares", title("Gr�fico de dispers�o"))

mreg_ME_SA<-lm(Cardio~Vida) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_ME_SA
abline(mreg_ME_SA, col=c("gray"), lwd=3)#nao aparece no gg plot, so no plot

cor(Vida, Cardio) #correla��o de -0.8133989, ou seja forte negativa

gg_MESA<-ggplot(data=df_SA ,aes(x=Vida, y=Cardio),cex.axis=4)+geom_point(aes(color=continent))+ geom_smooth(method = lm, se=FALSE) #grafico de dispers�o ggplt

ggplot_MESA<-gg_MESA+xlab("Esperan�a de vida")+ylab("Mortes Cardiovascular")+ggtitle("Grafico de dispersao")#com legendas
ggplot_MESA
summary(mreg_ME_SA)

#3 Variaveis

plot(Cardio, Vida+Diab)
mreg_MED_SA1<-lm(Vida+Diab~Cardio) #criar a reta de regress�o linear para apenas as 2 variaveis
mreg_MED_SA1
abline(mreg_MED_SA1, col=c("maroon"), lwd=2)#vizualizando-a

cor(Cardio, Vida+Diab) #correla��o de -0.3515606, ou seja baixa negativa

VD<-Vida+Diab
gg_MEdSA<-ggplot(data=df_SA ,aes(x=Cardio, y=VD), col=c("green"),cex.axis=4)+geom_point(aes(color=continent))+geom_smooth(method = lm, se=FALSE) #grafico de dispers�o ggplot
ggplot_MEdSA<-gg_MEdSA+xlab("Mortes Cardiovascular")+ylab("Esperan�a de vida e diabetes")+ggtitle("Grafico de dispersao - com 3 vari�veis") #com legendas
ggplot_MEdSA 

summary(mreg_MED_SA1) #R^2 para as 3 variaveis



















#-------------------------------------------------------------------------------------------------------
#clusters-----
#1�Tentativa------

ggplot(df_covid, aes(x=Mortes_Cardio , y= Esp_Vida))+geom_point(aes(color= continent))+labs(x='Mortes cardiovasculares',y='Esperan�a m�dia de vida',tittle = 'Diagrama de Dispers�o')

dados<-data.frame(Mortes_Cardio, Esp_Vida ,Diabetes)
d_dados<-round(dist(dados, method="euclidean"),1)
d_dados

#Para reproduzir o dendograma
scaled_covids<-scale(Mortes_Cardio)
dist_covid<-dist(scaled_covids,method = "euclidean")
dist_covid
AC<-hclust(dist_covid, method = "ward.D")
plot(AC, hang=0.05)

rect.hclust(AC,k=4)

#clusters 2�Tentativa (troca de variaveis) UTILIZADO NO RELATORIO.----------

ggplot(df_covid, aes(x=Diabetes , y= Esp_Vida))+geom_point(aes(color= continent))+labs(x='Diabetes',y='Esperan�a m�dia de vida',tittle = 'Diagrama de Dispers�o') #diagrama de dispersao 
#+geom_text(aes(label=iso_code)) #Para sabermos a que paises correspondem os pontos ao codigo a cima juntamos este.




with(df_covid,{
  s3d <-scatterplot3d(
    x=Esp_Vida,
    y=Mortes_Cardio,
    z=Diabetes,
    color="purple",
    pch=19, #formata os pontos de uma certa forma - podem experimentar outros valores
    type="h", # desenhar retas verticais que representam a projecao dos pontos
    main="Clusters", #titulo
    xlab="Esperan�a media de vida", # legendar eixo xx
    ylab="Mortes Cardiovasculares",
    zlab="Diabetes")
  
  #conversao de coordenadas 3D para 2D (para a projecao)
  coordenada<-s3d$xyz.convert(Esp_Vida,Mortes_Cardio, Diabetes)
  #para representar texto (etiquetas) junto aos pontos
  text(coordenada$x, coordenada$y, labels=row.names(df_covid), cex=0.8, pos=4)
})

dados1<-data.frame(Esp_Vida,Mortes_Cardio ,Diabetes)
d_dados1<-round(dist(dados1, method="euclidean"),1)
d_dados1


#Para reproduzir o dendograma
scaled_covids1<-scale(Esp_Vida)
dist_covid1<-dist(scaled_covids1,method = "euclidean")
dist_covid1
AC1<-hclust(dist_covid1, method = "ward.D2")
plot(AC1, hang=0.05)

rect.hclust(AC1,k=4)

fviz_nbclust(dados1,FUN=hcut,method ="silhouette",k.max = 9) #Elbow 


#clusters 3�Tentativa(troca de variaveis)----
with(df_covid,{
  s3d <-scatterplot3d(
    x=Diabetes,
    y=Mortes_Cardio,
    z=Esp_Vida,
    color="dark green",
    pch=19, #formata os pontos de uma certa forma - podem experimentar outros valores
    type="h", # desenhar retas verticais que representam a projecao dos pontos
    main="Clusters", #titulo
    xlab="Diabetes", # legendar eixo xx
    ylab="Mortes Cardiovasculares",
    zlab="Esperan�a media de vida")
  
  #conversao de coordenadas 3D para 2D (para a projecao)
  coordenada<-s3d$xyz.convert(Diabetes,Mortes_Cardio, Esp_Vida)
  #para representar texto (etiquetas) junto aos pontos
  text(coordenada$x, coordenada$y, labels=row.names(df_covid), cex=0.8, pos=4)
})
dados3<-data.frame(Diabetes,Mortes_Cardio ,Esp_Vida)
d_dados3<-round(dist(dados3, method="euclidean"),1)
d_dados3

#Para reproduzir o dendograma
scaled_covids3<-scale(Diabetes)
dist_covid3<-dist(scaled_covids3,method = "euclidean")
dist_covid3
AC3<-hclust(dist_covid3, method = "ward.D2")
plot(AC3, hang=0.05)

rect.hclust(AC3,k=4)



#-----------------------------------------------------------------------------------------------------------
#An�lise de componentes principais---------

df_covid_omit<-na.omit(df_covid)
View(df_covid_omit)

# vamos usar apenas colunas 3 a 23

df_PCA <-df_covid_omit[,3:25] 
View(df_PCA)

PCA<-prcomp(df_PCA, scale = TRUE)
PCA

#visualiza��o do gr�fico
fviz_eig(PCA)

# no sentido de se perceber a que continente corresponde
grupos <- as.factor(df_covid_omit$continent) 

#gr�fico no biplot
fviz_pca_biplot(PCA, 
                label="var", 
                habillage=grupos,
                legend.title = "Continente", 
                title= "Gr�fico ACP")

#eigenvalues
PCA$eig

#f variancia explicada por cada variavel
fviz_eig(PCA, geom="line")

#verifica��o da correla��o
corr<-get_pca_var(PCA)
#names(PCA) <- c("COL", "ETH", "GHA","KEN","MWI","MOZ","PRY","ZAF","TGO","TUN","UGA","ZMB","ZWE")
corrplot(corr$cos2,is.corr = T)

corrplot(corr$cos2,method = "number" , is.corr = T)



